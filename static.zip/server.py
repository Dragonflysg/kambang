from flask import Flask, render_template, request, jsonify
import os
import json
from datetime import datetime

app = Flask(__name__)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)


def get_project_path(project_name):
    """Get the full path for a project JSON file."""
    safe_name = "".join(c for c in project_name if c.isalnum() or c in (' ', '-', '_')).strip()
    safe_name = safe_name.replace(' ', '_')
    return os.path.join(DATA_DIR, f"{safe_name}.json")


@app.route('/')
def index():
    """Render the main application page."""
    return render_template('index.html')


@app.route('/api/projects', methods=['GET'])
def list_projects():
    """List all available projects."""
    projects = []
    for filename in os.listdir(DATA_DIR):
        if filename.endswith('.json'):
            filepath = os.path.join(DATA_DIR, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    projects.append({
                        'name': data.get('name', filename[:-5]),
                        'filename': filename[:-5],
                        'modified': data.get('modified', ''),
                        'created': data.get('created', '')
                    })
            except (json.JSONDecodeError, IOError):
                continue

    # Sort by modified date, newest first
    projects.sort(key=lambda x: x.get('modified', ''), reverse=True)
    return jsonify({'projects': projects})


@app.route('/api/projects', methods=['POST'])
def create_project():
    """Create a new project."""
    data = request.get_json()
    project_name = data.get('name', '').strip()

    if not project_name:
        return jsonify({'error': 'Project name is required'}), 400

    filepath = get_project_path(project_name)

    if os.path.exists(filepath):
        return jsonify({'error': 'Project already exists'}), 409

    now = datetime.now().isoformat()
    project_data = {
        'name': project_name,
        'created': now,
        'modified': now,
        'root': {
            'id': 'root',
            'label': project_name,
            'details': '',
            'children': []
        }
    }

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(project_data, f, indent=2, ensure_ascii=False)

    return jsonify({
        'message': 'Project created successfully',
        'project': project_data
    })


@app.route('/api/projects/<project_name>', methods=['GET'])
def load_project(project_name):
    """Load a specific project."""
    filepath = get_project_path(project_name)

    if not os.path.exists(filepath):
        return jsonify({'error': 'Project not found'}), 404

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            project_data = json.load(f)
        return jsonify({'project': project_data})
    except (json.JSONDecodeError, IOError) as e:
        return jsonify({'error': f'Failed to load project: {str(e)}'}), 500


@app.route('/api/projects/<project_name>', methods=['PUT'])
def save_project(project_name):
    """Save/update a project."""
    filepath = get_project_path(project_name)
    data = request.get_json()

    if not data:
        return jsonify({'error': 'No data provided'}), 400

    # Update modified timestamp
    data['modified'] = datetime.now().isoformat()

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return jsonify({'message': 'Project saved successfully'})
    except IOError as e:
        return jsonify({'error': f'Failed to save project: {str(e)}'}), 500


@app.route('/api/projects/<project_name>', methods=['DELETE'])
def delete_project(project_name):
    """Delete a project."""
    filepath = get_project_path(project_name)

    if not os.path.exists(filepath):
        return jsonify({'error': 'Project not found'}), 404

    try:
        os.remove(filepath)
        return jsonify({'message': 'Project deleted successfully'})
    except IOError as e:
        return jsonify({'error': f'Failed to delete project: {str(e)}'}), 500


if __name__ == '__main__':
    app.run(debug=True, port=5000)
