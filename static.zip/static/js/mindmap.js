/**
 * MindMap Renderer using D3.js
 * Handles node rendering, connections, zoom, and pan
 */

class MindMapRenderer {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.options = {
            nodeWidth: 180,
            nodeHeight: 70,
            nodeRadius: 12,
            horizontalSpacing: 250,
            verticalSpacing: 80,
            ...options
        };

        // Color palette for different depth levels
        this.depthColors = [
            '#4a90d9',  // Depth 0 - Blue
            '#7c4dff',  // Depth 1 - Purple
            '#00bcd4',  // Depth 2 - Cyan
            '#4caf50',  // Depth 3 - Green
            '#ff9800',  // Depth 4 - Orange
            '#e91e63',  // Depth 5 - Pink
            '#9c27b0',  // Depth 6 - Deep Purple
            '#009688',  // Depth 7 - Teal
        ];

        this.svg = null;
        this.g = null;
        this.zoom = null;
        this.data = null;
        this.selectedNode = null;
        this.currentZoom = 1;

        this.onNodeClick = null;
        this.onNodeRightClick = null;
        this.onNodeDoubleClick = null;

        this.init();
    }

    init() {
        const container = d3.select(`#${this.containerId}`);
        this.svg = container.select('svg');

        // Clear any existing content
        this.svg.selectAll('*').remove();

        // Create main group for zoom/pan
        this.g = this.svg.append('g').attr('class', 'mindmap-group');

        // Create defs for link gradients
        this.defs = this.svg.append('defs');

        // Create groups for links and nodes (links behind nodes)
        this.linksGroup = this.g.append('g').attr('class', 'links-group');
        this.nodesGroup = this.g.append('g').attr('class', 'nodes-group');

        // Setup zoom behavior
        this.zoom = d3.zoom()
            .scaleExtent([0.1, 3])
            .on('zoom', (event) => {
                this.g.attr('transform', event.transform);
                this.currentZoom = event.transform.k;
                if (this.onZoomChange) {
                    this.onZoomChange(Math.round(this.currentZoom * 100));
                }
            });

        this.svg.call(this.zoom);

        // Click on background to deselect
        this.svg.on('click', (event) => {
            if (event.target === this.svg.node()) {
                this.deselectNode();
            }
        });
    }

    getDepthColor(depth) {
        return this.depthColors[depth % this.depthColors.length];
    }

    setData(data) {
        this.data = data;
        this.render();
        this.centerView();
    }

    render() {
        if (!this.data) return;

        // Convert hierarchical data to D3 hierarchy
        const root = d3.hierarchy(this.data);

        // Create tree layout
        const treeLayout = d3.tree()
            .nodeSize([this.options.verticalSpacing, this.options.horizontalSpacing])
            .separation((a, b) => {
                return a.parent === b.parent ? 1.2 : 1.5;
            });

        // Apply layout
        treeLayout(root);

        // Get all nodes and links
        const nodes = root.descendants();
        const links = root.links();

        // Render links (curved lines)
        this.renderLinks(links);

        // Render nodes
        this.renderNodes(nodes);
    }

    renderLinks(links) {
        const self = this;

        // Custom organic bezier path generator
        function linkPath(d) {
            const sx = d.source.y, sy = d.source.x;
            const tx = d.target.y, ty = d.target.x;
            const dx = tx - sx;
            const dy = ty - sy;
            const cx1 = sx + dx * 0.5;
            const cy1 = sy + dy * 0.15;
            const cx2 = tx - dx * 0.5;
            const cy2 = ty - dy * 0.15;
            return `M ${sx},${sy} C ${cx1},${cy1} ${cx2},${cy2} ${tx},${ty}`;
        }

        // Update / create gradients in defs
        links.forEach(d => {
            const gradId = `link-grad-${d.target.data.id}`;
            const srcColor = self.getDepthColor(d.source.depth);
            const tgtColor = self.getDepthColor(d.target.depth);

            let grad = self.defs.select(`#${gradId}`);
            if (grad.empty()) {
                grad = self.defs.append('linearGradient')
                    .attr('id', gradId)
                    .attr('gradientUnits', 'userSpaceOnUse');
                grad.append('stop').attr('offset', '0%');
                grad.append('stop').attr('offset', '100%');
            }
            grad.attr('x1', d.source.y).attr('y1', d.source.x)
                .attr('x2', d.target.y).attr('y2', d.target.x);
            grad.select('stop:first-child')
                .attr('stop-color', srcColor)
                .attr('stop-opacity', 0.8);
            grad.select('stop:last-child')
                .attr('stop-color', tgtColor)
                .attr('stop-opacity', 0.45);
        });

        const linkSelection = this.linksGroup.selectAll('.link')
            .data(links, d => d.target.data.id);

        // Exit — remove orphaned gradients too
        linkSelection.exit().each(d => {
            self.defs.select(`#link-grad-${d.target.data.id}`).remove();
        }).remove();

        // Enter
        const linkEnter = linkSelection.enter()
            .append('path')
            .attr('class', 'link');

        // Enter + Update
        linkEnter.merge(linkSelection)
            .attr('d', linkPath)
            .attr('stroke', d => `url(#link-grad-${d.target.data.id})`)
            .attr('stroke-width', d => Math.max(1, 2.5 - d.source.depth * 0.5));
    }

    renderNodes(nodes) {
        const self = this;

        const nodeSelection = this.nodesGroup.selectAll('.node-group')
            .data(nodes, d => d.data.id);

        // Exit
        nodeSelection.exit().remove();

        // Enter
        const nodeEnter = nodeSelection.enter()
            .append('g')
            .attr('class', 'node-group')
            .attr('transform', d => `translate(${d.y}, ${d.x})`);

        // Add rectangle
        nodeEnter.append('rect')
            .attr('class', 'node-rect')
            .attr('x', -this.options.nodeWidth / 2)
            .attr('y', -this.options.nodeHeight / 2)
            .attr('width', this.options.nodeWidth)
            .attr('height', this.options.nodeHeight)
            .attr('rx', this.options.nodeRadius)
            .attr('ry', this.options.nodeRadius);

        // Main label text
        nodeEnter.append('text')
            .attr('class', 'node-text node-label-text')
            .attr('dy', '0em');

        // Sublabel text
        nodeEnter.append('text')
            .attr('class', 'node-text node-sublabel-text')
            .attr('dy', '1.3em')
            .attr('font-size', '11px')
            .attr('fill', 'rgba(0,0,0,0.65)')
            .attr('opacity', 1);

        // Add indicator for status / details
        nodeEnter.append('circle')
            .attr('class', 'details-indicator')
            .attr('cx', this.options.nodeWidth / 2 - 15)
            .attr('cy', -this.options.nodeHeight / 2 + 12)
            .attr('r', 6)
            .attr('fill', '#00d4ff')
            .attr('opacity', 0);

        // Merge enter + update
        const nodeUpdate = nodeEnter.merge(nodeSelection);

        nodeUpdate.attr('transform', d => `translate(${d.y}, ${d.x})`);

        // Update rectangle colors based on depth
        nodeUpdate.select('.node-rect')
            .attr('fill', d => this.getDepthColor(d.depth))
            .attr('stroke', d => d3.color(this.getDepthColor(d.depth)).darker(0.5))
            .attr('stroke-width', 2);

        // Update label position based on whether sublabel exists
        nodeUpdate.select('.node-label-text')
            .text(d => self.truncateText(d.data.label, 22))
            .attr('dy', d => (d.data.sublabel && d.data.sublabel.trim()) ? '-0.35em' : '0.35em');

        // Update sublabel
        nodeUpdate.select('.node-sublabel-text')
            .text(d => d.data.sublabel ? self.truncateText(d.data.sublabel, 24) : '')
            .attr('dy', d => (d.data.sublabel && d.data.sublabel.trim()) ? '0.9em' : '0em')
            .attr('fill', 'rgba(0,0,0,0.65)')
            .attr('opacity', d => (d.data.sublabel && d.data.sublabel.trim()) ? 1 : 0);

        // Update indicator: red if flagged, cyan if has details, hidden otherwise
        nodeUpdate.select('.details-indicator')
            .attr('fill', d => d.data.status === 'flagged' ? '#f85149' : '#00d4ff')
            .attr('opacity', d => {
                if (d.data.status === 'flagged') return 1;
                if (d.data.details && d.data.details.trim()) return 1;
                return 0;
            });

        // Update selected state
        nodeUpdate.classed('selected', d => this.selectedNode && d.data.id === this.selectedNode.data.id);

        // Event handlers
        nodeUpdate
            .on('click', function(event, d) {
                event.stopPropagation();
                self.selectNode(d);
                if (self.onNodeClick) {
                    self.onNodeClick(d);
                }
            })
            .on('dblclick', function(event, d) {
                event.stopPropagation();
                if (self.onNodeDoubleClick) {
                    self.onNodeDoubleClick(d);
                }
            })
            .on('contextmenu', function(event, d) {
                event.preventDefault();
                event.stopPropagation();
                self.selectNode(d);
                if (self.onNodeRightClick) {
                    self.onNodeRightClick(event, d);
                }
            });
    }

    truncateText(text, maxLength) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength - 3) + '...';
    }

    selectNode(node) {
        this.selectedNode = node;
        this.nodesGroup.selectAll('.node-group')
            .classed('selected', d => d.data.id === node.data.id);
    }

    deselectNode() {
        this.selectedNode = null;
        this.nodesGroup.selectAll('.node-group').classed('selected', false);
        if (this.onNodeDeselect) {
            this.onNodeDeselect();
        }
    }

    getSelectedNode() {
        return this.selectedNode;
    }

    centerView() {
        if (!this.data) return;

        const svgNode = this.svg.node();
        const bounds = svgNode.getBoundingClientRect();
        const width = bounds.width;
        const height = bounds.height;

        // Reset zoom and center
        this.svg.transition()
            .duration(500)
            .call(
                this.zoom.transform,
                d3.zoomIdentity
                    .translate(width / 4, height / 2)
                    .scale(0.8)
            );
    }

    zoomIn() {
        this.svg.transition()
            .duration(300)
            .call(this.zoom.scaleBy, 1.3);
    }

    zoomOut() {
        this.svg.transition()
            .duration(300)
            .call(this.zoom.scaleBy, 0.7);
    }

    resetZoom() {
        this.centerView();
    }

    setZoomLevel(level) {
        const currentTransform = d3.zoomTransform(this.svg.node());
        this.svg.transition()
            .duration(300)
            .call(
                this.zoom.transform,
                d3.zoomIdentity
                    .translate(currentTransform.x, currentTransform.y)
                    .scale(level / 100)
            );
    }

    // Helper to generate unique IDs
    static generateId() {
        return 'node_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Find a node by ID in the data tree
    findNodeById(node, id) {
        if (node.id === id) return node;
        if (node.children) {
            for (const child of node.children) {
                const found = this.findNodeById(child, id);
                if (found) return found;
            }
        }
        return null;
    }

    // Find parent of a node by ID
    findParentById(node, id, parent = null) {
        if (node.id === id) return parent;
        if (node.children) {
            for (const child of node.children) {
                const found = this.findParentById(child, id, node);
                if (found) return found;
            }
        }
        return null;
    }

    // Add a child node to the selected node
    addChildToSelected(label = 'New Node') {
        if (!this.selectedNode) return null;

        const parentData = this.findNodeById(this.data, this.selectedNode.data.id);
        if (!parentData) return null;

        if (!parentData.children) {
            parentData.children = [];
        }

        const newNode = {
            id: MindMapRenderer.generateId(),
            label: label,
            sublabel: '',
            details: '',
            specialNotes: '',
            status: 'none',
            children: []
        };

        parentData.children.push(newNode);
        this.render();

        // Auto-focus the newly created node
        let newD3Node = null;
        this.nodesGroup.selectAll('.node-group').each(function(d) {
            if (d.data.id === newNode.id) newD3Node = d;
        });
        if (newD3Node) {
            this.selectNode(newD3Node);
            if (this.onNodeClick) this.onNodeClick(newD3Node);
        }

        return newNode;
    }

    // Delete the selected node (except root)
    deleteSelected() {
        if (!this.selectedNode || this.selectedNode.depth === 0) {
            return false; // Can't delete root
        }

        const parent = this.findParentById(this.data, this.selectedNode.data.id);
        if (!parent) return false;

        const index = parent.children.findIndex(c => c.id === this.selectedNode.data.id);
        if (index > -1) {
            parent.children.splice(index, 1);
            this.deselectNode();
            this.render();
            return true;
        }

        return false;
    }

    // Update a node's data
    updateNodeData(nodeId, updates) {
        const node = this.findNodeById(this.data, nodeId);
        if (node) {
            Object.assign(node, updates);
            this.render();
            return true;
        }
        return false;
    }

    // Get the raw data
    getData() {
        return this.data;
    }
}

// Export for use in app.js
window.MindMapRenderer = MindMapRenderer;
