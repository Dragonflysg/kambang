/**
 * MindMap Application
 * Main application logic using jQuery
 */

$(document).ready(function() {
    // Application state
    let currentProject = null;
    let mindmap = null;
    let isDirty = false;
    let currentNodeStatus = 'none';

    // Initialize the mind map renderer
    function initMindMap() {
        mindmap = new MindMapRenderer('mindmap-container', {
            nodeWidth: 180,
            nodeHeight: 70,
            horizontalSpacing: 280,
            verticalSpacing: 90
        });

        // Event handlers
        mindmap.onNodeClick = handleNodeClick;
        mindmap.onNodeRightClick = handleNodeRightClick;
        mindmap.onNodeDoubleClick = handleNodeDoubleClick;
        mindmap.onNodeDeselect = handleNodeDeselect;
        mindmap.onZoomChange = handleZoomChange;
    }

    // Modal handling
    function showModal(modalId) {
        $(`#${modalId}`).addClass('active');
    }

    function hideModal(modalId) {
        $(`#${modalId}`).removeClass('active');
    }

    function hideAllModals() {
        $('.modal').removeClass('active');
    }

    // Toast notifications
    function showToast(message, type = 'info') {
        const toast = $(`<div class="toast ${type}">${message}</div>`);
        $('#toast-container').append(toast);

        setTimeout(() => {
            toast.fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }

    // Format date for display
    function formatDate(isoString) {
        if (!isoString) return '';
        const date = new Date(isoString);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    }

    // ========================= Sidebar =========================

    // Load projects into the sidebar list
    function loadSidebarProjects() {
        const $list = $('#sidebar-project-list');
        $list.html('<p class="loading">Loading...</p>');

        $.get('/api/projects')
            .done(function(response) {
                const projects = response.projects;

                if (!projects || projects.length === 0) {
                    $list.html('<p class="empty-message">No projects found.</p>');
                    return;
                }

                let html = '';
                projects.forEach(function(project) {
                    const isActive = currentProject && currentProject.name === project.name;
                    html += `
                        <div class="sidebar-project-item${isActive ? ' active' : ''}" data-name="${project.filename}">
                            <div class="sidebar-project-info">
                                <div class="sidebar-project-name">${project.name}</div>
                                <div class="sidebar-project-date">${formatDate(project.modified)}</div>
                            </div>
                            <button class="sidebar-project-delete" data-name="${project.filename}" title="Delete project">
                                &#128465;
                            </button>
                        </div>
                    `;
                });

                $list.html(html);
            })
            .fail(function() {
                $list.html('<p class="empty-message">Failed to load projects.</p>');
                showToast('Failed to load projects', 'error');
            });
    }

    // Toggle sidebar open / collapsed
    function toggleSidebar() {
        $('#sidebar').toggleClass('collapsed');
    }

    // Highlight the currently loaded project in sidebar
    function highlightActiveProject() {
        $('.sidebar-project-item').removeClass('active');
        if (currentProject) {
            const filename = currentProject.name.replace(/ /g, '_');
            $(`.sidebar-project-item`).each(function() {
                const itemName = $(this).data('name');
                if (itemName === filename || itemName === currentProject.filename) {
                    $(this).addClass('active');
                }
            });
        }
    }

    // ========================= Project CRUD =========================

    // Create new project
    function createProject(name) {
        $.ajax({
            url: '/api/projects',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ name: name })
        })
        .done(function(response) {
            currentProject = response.project;
            hideAllModals();
            openEditor();
            loadSidebarProjects();
            showToast('Project created successfully', 'success');
        })
        .fail(function(xhr) {
            const error = xhr.responseJSON?.error || 'Failed to create project';
            showToast(error, 'error');
        });
    }

    // Load project
    function loadProject(projectName) {
        $.get(`/api/projects/${encodeURIComponent(projectName)}`)
            .done(function(response) {
                currentProject = response.project;
                hideAllModals();
                openEditor();
                highlightActiveProject();
                showToast('Project loaded', 'success');
            })
            .fail(function() {
                showToast('Failed to load project', 'error');
            });
    }

    // Save project
    function saveProject() {
        if (!currentProject) return;

        // Update the root data from mindmap
        currentProject.root = mindmap.getData();

        const projectName = currentProject.name.replace(/ /g, '_');

        $.ajax({
            url: `/api/projects/${encodeURIComponent(projectName)}`,
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(currentProject)
        })
        .done(function() {
            isDirty = false;
            showToast('Project saved', 'success');
        })
        .fail(function() {
            showToast('Failed to save project', 'error');
        });
    }

    // Delete project
    function deleteProject(projectName) {
        if (!confirm('Are you sure you want to delete this project?')) {
            return;
        }

        $.ajax({
            url: `/api/projects/${encodeURIComponent(projectName)}`,
            method: 'DELETE'
        })
        .done(function() {
            // If the deleted project was the active one, clear the editor
            if (currentProject && (currentProject.name.replace(/ /g, '_') === projectName || currentProject.filename === projectName)) {
                currentProject = null;
                $('#project-title').text('MindMap');
                isDirty = false;
                if (mindmap) {
                    mindmap.setData(null);
                }
                closeDetailsPanel();
            }
            loadSidebarProjects();
            showToast('Project deleted', 'success');
        })
        .fail(function() {
            showToast('Failed to delete project', 'error');
        });
    }

    // Open editor with current project data
    function openEditor() {
        if (!currentProject) return;

        $('#project-title').text(currentProject.name);

        // Initialize mindmap if not already done
        if (!mindmap) {
            initMindMap();
        }

        // Load data into mindmap
        mindmap.setData(currentProject.root);
        isDirty = false;
    }

    // Mark as dirty (unsaved changes)
    function markDirty() {
        isDirty = true;
    }

    // ========================= Node Handlers =========================

    function handleNodeClick(node) {
        openDetailsPanel(node);
    }

    function handleNodeRightClick(event, node) {
        showContextMenu(event.pageX, event.pageY, node);
    }

    function handleNodeDoubleClick(node) {
        openDetailsPanel(node);
        $('#node-label').focus().select();
    }

    function handleNodeDeselect() {
        closeDetailsPanel();
    }

    function handleZoomChange(zoomPercent) {
        $('#zoom-level').text(zoomPercent + '%');
    }

    // Status UI helper
    function updateStatusUI(status) {
        if (status === 'flagged') {
            $('#btn-status-flag').addClass('flagged');
            $('.status-label-text').text('Flagged').addClass('flagged');
        } else {
            $('#btn-status-flag').removeClass('flagged');
            $('.status-label-text').text('No flag').removeClass('flagged');
        }
    }

    // Details panel
    function openDetailsPanel(node) {
        $('#panel-node-title').text(node.data.label || 'Node Details');
        $('#node-label').val(node.data.label || '');
        $('#node-sublabel').val(node.data.sublabel || '');
        $('#node-details').val(node.data.details || '');
        $('#node-special-notes').val(node.data.specialNotes || '');
        currentNodeStatus = node.data.status || 'none';
        updateStatusUI(currentNodeStatus);
        $('#details-panel').addClass('open');
    }

    function closeDetailsPanel() {
        $('#details-panel').removeClass('open');
    }

    function applyNodeChanges() {
        const selected = mindmap.getSelectedNode();
        if (!selected) return;

        const newLabel = $('#node-label').val().trim();
        const newSublabel = $('#node-sublabel').val();
        const newDetails = $('#node-details').val();
        const newSpecialNotes = $('#node-special-notes').val();

        if (!newLabel) {
            showToast('Label cannot be empty', 'error');
            return;
        }

        mindmap.updateNodeData(selected.data.id, {
            label: newLabel,
            sublabel: newSublabel,
            details: newDetails,
            specialNotes: newSpecialNotes,
            status: currentNodeStatus
        });

        $('#panel-node-title').text(newLabel);
        markDirty();
        showToast('Changes applied', 'success');
    }

    // Context menu
    function showContextMenu(x, y, node) {
        const menu = $('#context-menu');

        const menuWidth = 160;
        const menuHeight = 120;

        if (x + menuWidth > window.innerWidth) {
            x = window.innerWidth - menuWidth - 10;
        }
        if (y + menuHeight > window.innerHeight) {
            y = window.innerHeight - menuHeight - 10;
        }

        menu.css({
            left: x + 'px',
            top: y + 'px'
        }).addClass('active');

        // Disable delete for root node
        if (node.depth === 0) {
            $('#ctx-delete').css('opacity', '0.5').css('pointer-events', 'none');
        } else {
            $('#ctx-delete').css('opacity', '1').css('pointer-events', 'auto');
        }
    }

    function hideContextMenu() {
        $('#context-menu').removeClass('active');
    }

    // Add child node
    function addChildNode() {
        const selected = mindmap.getSelectedNode();
        if (!selected) {
            showToast('Please select a node first', 'error');
            return;
        }

        const newNode = mindmap.addChildToSelected('New Node');
        if (newNode) {
            markDirty();
            showToast('Node added', 'success');
        }
    }

    // Delete selected node
    function deleteSelectedNode() {
        const selected = mindmap.getSelectedNode();
        if (!selected) {
            showToast('Please select a node first', 'error');
            return;
        }

        if (selected.depth === 0) {
            showToast('Cannot delete root node', 'error');
            return;
        }

        if (confirm('Delete this node and all its children?')) {
            if (mindmap.deleteSelected()) {
                closeDetailsPanel();
                markDirty();
                showToast('Node deleted', 'success');
            }
        }
    }

    // ==================== Event Bindings ====================

    // Sidebar NEW button - opens the create modal
    $('#sidebar-btn-new').on('click', function() {
        $('#new-project-name').val('');
        showModal('modal-new');
        setTimeout(() => $('#new-project-name').focus(), 100);
    });

    // Sidebar toggle tab
    $('#sidebar-tab').on('click', function() {
        toggleSidebar();
    });

    // Sidebar project item click - load the project
    $(document).on('click', '.sidebar-project-item', function(e) {
        if ($(e.target).hasClass('sidebar-project-delete')) return;
        if (isDirty) {
            if (!confirm('You have unsaved changes. Load a different project?')) {
                return;
            }
        }
        const name = $(this).data('name');
        loadProject(name);
    });

    // Sidebar project delete button
    $(document).on('click', '.sidebar-project-delete', function(e) {
        e.stopPropagation();
        const name = $(this).data('name');
        deleteProject(name);
    });

    // Modal close buttons
    $('.modal-close, .modal-cancel').on('click', function() {
        hideAllModals();
    });

    // Close modal on backdrop click
    $('.modal').on('click', function(e) {
        if (e.target === this) {
            hideAllModals();
        }
    });

    // Create project
    $('#btn-create-project').on('click', function() {
        const name = $('#new-project-name').val().trim();
        if (!name) {
            showToast('Please enter a project name', 'error');
            return;
        }
        createProject(name);
    });

    // Enter key in project name input
    $('#new-project-name').on('keypress', function(e) {
        if (e.which === 13) {
            $('#btn-create-project').click();
        }
    });

    // Editor header buttons
    $('#btn-save').on('click', saveProject);
    $('#btn-add-child').on('click', addChildNode);
    $('#btn-delete-node').on('click', deleteSelectedNode);

    // Zoom controls
    $('#btn-zoom-in').on('click', function() {
        if (mindmap) mindmap.zoomIn();
    });

    $('#btn-zoom-out').on('click', function() {
        if (mindmap) mindmap.zoomOut();
    });

    $('#btn-zoom-reset').on('click', function() {
        if (mindmap) mindmap.resetZoom();
    });

    // Details panel
    $('#btn-close-panel').on('click', function() {
        closeDetailsPanel();
        if (mindmap) mindmap.deselectNode();
    });

    // Panel tab toggle
    $('#panel-tab').on('click', function() {
        if ($('#details-panel').hasClass('open')) {
            closeDetailsPanel();
            if (mindmap) mindmap.deselectNode();
        }
        // If closed, do nothing (user must click a node to reopen)
    });

    // Panel resize
    let isResizingPanel = false;
    let panelResizeStartX = 0;
    let panelResizeStartWidth = 0;

    $('#panel-resize-handle').on('mousedown', function(e) {
        isResizingPanel = true;
        panelResizeStartX = e.clientX;
        panelResizeStartWidth = $('#details-panel').width();
        $(this).addClass('active');
        e.preventDefault();
    });

    $(document).on('mousemove', function(e) {
        if (!isResizingPanel) return;
        const delta = panelResizeStartX - e.clientX;
        const newWidth = Math.min(600, Math.max(260, panelResizeStartWidth + delta));
        $('#details-panel').css('width', newWidth + 'px');
    });

    $(document).on('mouseup', function() {
        if (isResizingPanel) {
            isResizingPanel = false;
            $('#panel-resize-handle').removeClass('active');
        }
    });

    // Status flag toggle
    $('#btn-status-flag').on('click', function() {
        currentNodeStatus = currentNodeStatus === 'flagged' ? 'none' : 'flagged';
        updateStatusUI(currentNodeStatus);
    });

    $('#btn-apply-changes').on('click', applyNodeChanges);

    // Apply changes on Enter in label field
    $('#node-label').on('keypress', function(e) {
        if (e.which === 13) {
            applyNodeChanges();
        }
    });

    // Context menu actions
    $('#ctx-add-child').on('click', function() {
        hideContextMenu();
        addChildNode();
    });

    $('#ctx-edit').on('click', function() {
        hideContextMenu();
        const selected = mindmap.getSelectedNode();
        if (selected) {
            openDetailsPanel(selected);
            $('#node-label').focus().select();
        }
    });

    $('#ctx-delete').on('click', function() {
        hideContextMenu();
        deleteSelectedNode();
    });

    // Hide context menu on click elsewhere
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#context-menu').length) {
            hideContextMenu();
        }
    });

    // Keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Ignore if typing in input/textarea
        if ($(e.target).is('input, textarea')) return;

        // Ctrl+S to save
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            saveProject();
        }

        // Delete key to delete node
        if (e.key === 'Delete') {
            deleteSelectedNode();
        }

        // Escape to deselect/close panel
        if (e.key === 'Escape') {
            if ($('#details-panel').hasClass('open')) {
                closeDetailsPanel();
                if (mindmap) mindmap.deselectNode();
            }
            hideContextMenu();
        }

        // + to zoom in
        if (e.key === '+' || e.key === '=') {
            if (mindmap) mindmap.zoomIn();
        }

        // - to zoom out
        if (e.key === '-') {
            if (mindmap) mindmap.zoomOut();
        }
    });

    // Escape key to close modals
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            hideAllModals();
            hideContextMenu();
        }
    });

    // Warn before leaving with unsaved changes
    $(window).on('beforeunload', function() {
        if (isDirty) {
            return 'You have unsaved changes. Are you sure you want to leave?';
        }
    });

    // Handle window resize
    $(window).on('resize', function() {
        if (mindmap && currentProject) {
            setTimeout(() => mindmap.centerView(), 100);
        }
    });

    // ==================== Initialization ====================
    // Editor page is shown by default (no landing page).
    // Initialize the mindmap renderer immediately so the canvas is ready.
    initMindMap();

    // Load the sidebar project list on startup.
    loadSidebarProjects();
});
